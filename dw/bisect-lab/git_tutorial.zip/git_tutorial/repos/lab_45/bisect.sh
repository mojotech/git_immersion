#!/usr/bin/env bash

if [ -e lib/hello.rb ]
then
    if ruby -Ilib lib/hello.rb BisectString | grep BisectString
    then
        exit 1
    else
        exit 0
    fi
elif [ -e hello.rb ]
then
    if ruby hello.rb BisectString | grep BisectString
    then
        exit 1
    else
        exit 0
    fi
fi
