puts "Hello, #{ARGV.first}!"
