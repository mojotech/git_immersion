# Default is World
# Author: Jim Weirich (jim@somewhere.com)
names = ARGV || ["World"]

puts "Hello, #{names.join(" ")}!"
puts "You have #{names.length} names!"
