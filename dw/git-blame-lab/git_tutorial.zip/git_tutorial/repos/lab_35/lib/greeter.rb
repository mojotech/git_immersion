  def initialize(who, excited = true, unsure = true)
    @who = who
    @excited = excited
    @unsure = unsure
  end
  def greet
    "Hello, #{@who}#{punctuation}"
  end
  def punctuation
    punct = ""
    if @excited
        punct += "!"
    else
        punct += "."
    end
    if @unsure
        punct += "?"
    end
    punct
  end
end
