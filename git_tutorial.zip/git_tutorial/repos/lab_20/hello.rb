names = ARGV || ["World"]

puts "Hello, #{names.join(" ")}!"
puts "You have #{names.length} names!"
puts "You have #{names.length} names!"
